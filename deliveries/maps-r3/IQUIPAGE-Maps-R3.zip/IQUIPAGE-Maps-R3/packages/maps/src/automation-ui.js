import {clone,uid,requireValue} from './common.js';
import {createRule,validateRule,TRIGGER_LABELS} from './events.js';
import {button,input,textarea,select,check,dialog,esc,icon,date,pretty,statusNames,download} from './ui.js';

export function installAutomationUI(feature) {
  feature.automationActions={automations:()=>showAutomations(feature),'new-automation':()=>editRule(feature),'edit-automation':control=>editRule(feature,control.dataset.ruleId),'test-event':()=>sendEvent(feature)};
}
async function showAutomations(feature) {
  const rules=(await feature.repository.list('rules',feature.project.id)).filter(r=>r.mapId===feature.current.id);
  const connected=!!feature.repository.capabilities?.events;
  feature.openPanel('automations','Автоматизация по событиям',`<p>Запускайте опубликованную версию сценария по расписанию или событию.</p><p class="map-explanation">${connected?'Подключён локальный reference runtime. Расписание работает, пока сервер запущен.':'Сервер событий не подключён. Настройки можно сохранить как черновик и передать агенту интеграции.'}</p><div class="map-rule-list">${rules.length?rules.map(r=>`<button type="button" class="map-list-row" data-map-action="edit-automation" data-rule-id="${r.id}"><span><b>${esc(r.name)}</b><small>${esc(TRIGGER_LABELS[r.trigger])} · ${esc(statusNames[r.status]||r.status)}</small><small>${r.trigger==='schedule'?esc(`${r.schedule.time} / ${r.schedule.timeZone}`):r.trigger==='project'?esc(r.eventType):'Входящий запрос'} · Версия карты ${r.mapRevision}</small></span>${icon('chevron',15)}</button>`).join(''):'<p class="map-empty-copy">Правил ещё нет.</p>'}</div>${feature.permissions.manageAutomation&&feature.current.status!=='archived'?button('new-automation','Добавить правило','plus','primary'):''}${connected?button('test-event','Отправить тестовое событие','bolt','secondary'):''}<details class="iq-accordion"><summary>Как это работает ${icon('plus',16)}</summary><div><p>Правило закрепляет версию сценария. Правка карты не обновляет её автоматически. Повтор того же события не создаёт второй запуск.</p><p>Действия, которые записывают данные, всё равно требуют подтверждения человека. Архивная карта больше не запускается автоматически.</p><p>Входящие запросы подписываются на сервере. API-ключи не хранятся в карте.</p></div></details>`);
}
async function editRule(feature,id) {
  requireValue(feature.permissions.manageAutomation&&feature.current.status!=='archived','PERMISSION','Изменение автоматизации недоступно.');
  const existing=id?await feature.repository.read('rules',id,feature.project.id):null,rule=existing||createRule(feature.current);
  requireValue(rule,'NOT_FOUND','Правило не найдено.');let trigger=rule.trigger;
  const capabilities=feature.repository.capabilities||{};
  const el=feature.dialog({title:id?'Настроить автоматизацию':'Новое правило запуска',description:'Включение закрепляет текущую версию сценария. Неподключённые возможности остаются черновиками.',wide:true,body:`<div class="map-rule-editor"><div>${input('name','Название',rule.name,{required:true})}${select('trigger','Что запускает сценарий',trigger,Object.entries(TRIGGER_LABELS).filter(([id])=>id!=='manual'))}<div data-trigger-settings></div></div><div>${select('inputSource','Откуда взять заметки',rule.inputSource||'map-notes',[['map-notes','Из заметок и действий этой карты'],['event-notes','Из поля notes входящего события']])}${select('status','Состояние',rule.status,[['draft','Черновик — не запускается'],['enabled','Включено'],['paused','Приостановлено']])}<p class="map-explanation">${capabilities.events?'Сейчас используется локальный сервер. В промышленной платформе правило выполняется очередью независимых работников.':'Без сервера можно сохранить и экспортировать только черновик.'}</p><p class="map-explanation">Запуски после включения используют версию карты ${feature.current.revision}. ${existing&&existing.mapRevision!==feature.current.revision?`Сейчас в правиле закреплена версия ${existing.mapRevision}. Сохранение обновит её.`:''}</p>${id?'<button type="button" class="iq-btn secondary sm" data-export-rule>Экспортировать контракт</button>':''}</div></div>`,submitLabel:'Сохранить правило',onSubmit:async values=>{
    if(!(await feature.readyToLeave()))throw Error('Сначала сохраните карту.');
    const next={...clone(rule),name:values.get('name').trim(),trigger:values.get('trigger'),status:values.get('status'),inputSource:values.get('inputSource'),mapRevision:feature.current.revision,flowSnapshot:clone(feature.current.flow)};
    if(next.trigger==='schedule')next.schedule={time:values.get('time'),timeZone:values.get('timeZone').trim(),weekdays:[0,1,2,3,4,5,6].filter(d=>values.has(`day-${d}`)),missed:'skip',repeatedHour:'once'};
    if(next.trigger==='project')next.eventType=values.get('eventType');
    const errors=validateRule(next);requireValue(!errors.length,'INVALID_RULE',errors.map(e=>e.message).join(' '));
    if(next.status==='enabled'){requireValue(capabilities.events,'EVENTS_NOT_CONNECTED','Сервер событий не подключён. Сохраните черновик.');if(next.trigger==='webhook')requireValue(capabilities.webhook,'HOOK_DISABLED','На сервере ещё не настроена подпись входящих запросов. Сохраните черновик.');}
    await feature.repository.write('rules',next,rule.revision);await showAutomations(feature);
  },mount:el=>{
    const settings=el.querySelector('[data-trigger-settings]');
    const draw=()=>{
      settings.innerHTML=trigger==='schedule'?`${input('time','Время',rule.schedule?.time||'09:00',{placeholder:'09:00',required:true})}${input('timeZone','Часовой пояс',rule.schedule?.timeZone||Intl.DateTimeFormat().resolvedOptions().timeZone,{required:true})}<fieldset class="map-days"><legend>Дни недели</legend>${[[1,'Пн'],[2,'Вт'],[3,'Ср'],[4,'Чт'],[5,'Пт'],[6,'Сб'],[0,'Вс']].map(([d,label])=>check(`day-${d}`,label,(rule.schedule?.weekdays||[1,2,3,4,5]).includes(d))).join('')}</fieldset><p class="map-explanation">Пропущенное время не догоняется. При переводе часов повторная минута запускается один раз; несуществующее время пропускается.</p>`:trigger==='project'?`${select('eventType','Событие',rule.eventType||'session.archived',[['session.archived','Обсуждение завершено и сохранено'],['map.updated','Карта обновлена'],['task.completed','Задача выполнена']])}<p class="map-explanation">Платформа отправляет событие после подтверждённой записи. В локальном стенде его можно отправить явно через «Тестовое событие».</p>`:`<p class="map-explanation">После настройки сервер принимает подписанные запросы для этого правила. Ключ хранится в переменной окружения сервера, а не в документе.</p>${input('endpoint','Путь входящего запроса',`/api/hooks/${rule.id}`)}<p class="map-explanation">Тело: id, projectId, type, data.notes. Заголовки X-Maps-Timestamp и X-Maps-Signature. Подпись HMAC-SHA256(timestamp + "." + исходное тело), окно 5 минут.</p>`;
      settings.querySelector('[name=endpoint]')?.setAttribute('readonly','');
    };draw();
    el.querySelector('iq-select[name=trigger]').addEventListener('iq-change',e=>{trigger=e.target.value;draw();});
    el.querySelector('[data-export-rule]')?.addEventListener('click',()=>download('automation-rule.json',rule));
  }});return el;
}
function sendEvent(feature) {
  requireValue(feature.permissions.manageAutomation&&feature.repository.request,'EVENTS_NOT_CONNECTED','Для отправки нужен серверный адаптер.');
  const id=uid('event');
  feature.dialog({title:'Тестовое событие проекта',description:'Это реальное событие локального стенда. Включённые правила могут создать запуск, который остановится на подтверждении.',body:`${input('id','Идентификатор события',id,{required:true})}${select('type','Тип','session.archived',[['session.archived','Обсуждение завершено'],['map.updated','Карта обновлена'],['task.completed','Задача выполнена']])}${textarea('notes','Заметки события','Проверить критерии готовности\nПодготовить следующий эксперимент',4)}<p class="map-explanation">Повторите тот же идентификатор с теми же данными, чтобы проверить защиту от повторного запуска.</p>`,submitLabel:'Отправить событие',onSubmit:async values=>{
    const result=await feature.repository.request('/events',{method:'POST',body:{id:values.get('id'),projectId:feature.project.id,type:values.get('type'),depth:0,data:{notes:values.get('notes').split('\n').filter(s=>s.trim())}}});
    feature.openPanel('events','Событие обработано',`<p class="map-explanation">Результат локального сервера. Пустой список означает, что подходящих включённых правил нет.</p>${pretty(result)}${button('runs','Открыть запуски','clock','secondary')}`);
  }});
}
